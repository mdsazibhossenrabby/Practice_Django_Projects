from django.shortcuts import render

def coursespage(request):
    return render(request, "courses.html")

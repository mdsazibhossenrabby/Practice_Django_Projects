from django.shortcuts import render

# Create your views here.

def aboutuspages(request):
    return render(request,"aboutus.html")

from django.shortcuts import render

# Create your views here.
def contentpage(request):
    return render(request,"content.html")
